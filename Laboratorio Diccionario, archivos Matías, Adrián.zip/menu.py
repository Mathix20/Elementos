#Elaborado por: Matías Cedeño León, Adrián Dittel Retana
#Fecha de Creación: 08/05/2019 8:00am
#Fecha de modificación: 09/05/2019 6:53pm
#Version: 3.7.2

#importación de librerías

from menuMC import*
from funciones import*


def menu():
    """
    Funcionamiento: De manera repetitiva, muestra el menú al usuario. 
    Entradas: NA
    Salidas: Resultado según lo solicitado
    """
    diccMenu=leer ("inventario")
    while True:
        print("Menú McDonalds")
        print("1-Insertar Comida")
        print("2-Modificar Comida")
        print("3-Eliminar Comida")
        print("4-Consultar Comida")
        print("5-Terminar")
        opcion = int(input("Opción: "))
        if opcion == 1:
            agregarProd(diccMenu)
        elif opcion == 2:
            codigo = input("Indique el código a modificar: ").upper()
            modificarComida(diccMenu, codigo)
        elif opcion == 3:
            codigo = input("Indique el código a eliminar: ").upper()
            eliminarComida(diccMenu,codigo)
        elif opcion == 4:
            cond=int(input("Comida específica(1) o Todos los productos(2): "))
            if cond==1:
                codigo = input("Indique el código a mostrar: ").upper()
                mostrarComida(diccMenu,codigo)
            elif cond==2:
                mostrarTodasComidas(diccMenu)
            else:
                print("Indique un valor correcto (1-2)")
                cond=int(input("Comida específica(1) o Todos los productos(2): ")) 
        elif opcion == 5:
            grabarCerrar("inventario",diccMenu)
            break
#Programa Principal
menu()

