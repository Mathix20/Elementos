#Elaborado por: Matías Cedeño León, Adrián Dittel Retana
#Fecha de Creación: 08/05/2019 8:00am
#Fecha de modificación: 09/05/2019 6:53pm
#Version: 3.7.2

#importación de librerías
from menuMC import*

#Definicion de funciones
def agregarIngred():
    """
    Entradas: Cantidad de ingredientes, cuales ingredientes son
    Funcionamiento: Ingresa los ingredientes
    Salidas: lista de los ingredientes
    """
    ingred=[]
    t=int(input("¿Cuántos ingredientes lleva?: "))
    while t>0:
        ingred.append(input("Ingrese Ingrediente: "))
        t-=1
    return ingred
def agregarProd(diccMenu):
    """
    Entradas: Codigo,nombre,precio, ingredientes
    Funcionamiento: Crea los datos de la comida
    Salidas: Datos de la comida
    """
    try:
        codigo = input("Código: ").upper()
        nombre = input("Nombre: ").upper()
        precio= int(input("Precio: "))
        ingred= agregarIngred()
        datosComida = [nombre,precio,ingred]
        diccMenu[codigo] = datosComida
        grabar("inventario",diccMenu)
        return diccMenu
    except:
        print("El precio debe ser un numero entero (Ej: 1000,2000,3000)")
        agregarProd(diccMenu)
def mostrarComida(diccMenu,codigo):
    """
    Entradas: Datos de la comida, el codigo del producto
    Funcionamiento: Muestra la información de la comida
    Salidas: productos
    """
    i=0
    while i<1:
        try:
            datosComida = diccMenu[codigo]
            print("Código:",codigo)
            print("Nombre:",datosComida[0])
            print("Precio:",datosComida[1])
            print("Ingredientes:",datosComida[2])
            print("-----------------------------------------------------")
            i=10
        except:
            print("El codigo no existe, digite un codigo que exista")
            codigo = input("Código: ").upper()
            i+1
            
def eliminarComida(diccMenu,codigo):
    """
    Entradas: Datos de la comida, el codigo del producto
    Funcionamiento: Elimina la información de la comida
    Salidas: Lista sin los datos eliminados
    """
    i=0
    while i<1:
        try:
            del(diccMenu[codigo])
            grabarEliminar("Comidas ",diccMenu)
            i=10
        except:
            print("El codigo no existe, digite un codigo que exista")
            codigo = input("Código: ").upper()
            i+1
        
def modificarComida(diccMenu, codigo):
    """
    Entradas: Datos de la comida, el codigo del producto
    Funcionamiento: Cambia la información de la comida
    Salidas: Lista modificada
    """
    eliminarComida(diccMenu,codigo)
    agregarProd(diccMenu)
def mostrarTodasComidas(diccMenu):
    """
    Entradas: Datos de la comida, el codigo del producto
    Funcionamiento: Muestra todos los productos con su informacion
    Salidas: productos
    """
    valores = list(diccMenu.keys())
    for valor in valores:
        mostrarComida(diccMenu,valor)
    print ("************************************************************")
