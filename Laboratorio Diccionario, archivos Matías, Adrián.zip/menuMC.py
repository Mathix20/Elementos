#Elaborado por: Matías Cedeño León, Adrián Dittel Retana
#Fecha de Creación: 08/05/2019 8:00am
#Fecha de modificación: 09/05/2019 6:53pm
#Version: 3.7.2

#importación de librerías
import pickle
diccMenu = {}
#Definicion de manejo de archivos
def grabar(nomArchGrabar,lista):
    """
    Funcionamiento:Graba la informacion en el archivo correspondiente
    """
    try:
        f=open(nomArchGrabar,"wb")
        pickle.dump(lista,f)
        print("Se ha guardado la comida exitosamente")
        print ("************************************************************")
        f.close()
    except:
        print("Error al grabar el archivo: ", nomArchGrabar)
def grabarCerrar(nomArchGrabar,lista):
    """
    Funcionamiento:Graba la informacion al salir del archivo 
    """
    try:
        f=open(nomArchGrabar,"wb")
        pickle.dump(lista,f)
        print("Muchas gracias por usar el McMenú")
        print ("************************************************************")
        f.close()
    except:
        print("Error al grabar el archivo: ", nomArchGrabar)
def grabarInicio(nomArchGrabar,lista):
    """
    Funcionamiento:Graba la informacion para crear el archivo
    """
    try:
        f=open(nomArchGrabar,"wb")
        pickle.dump(lista,f)
        f.close()
    except:
        print("Error al grabar el archivo: ", nomArchGrabar)
def grabarEliminar(nomArchGrabar,lista):
    """
    Funcionamiento:Graba la informacion al eliminar un producto
    """
    try:
        f=open(nomArchGrabar,"wb")
        pickle.dump(lista,f)
        print("Se ha eliminado correctamente el valor anterior")
        print ("************************************************************")
        f.close()
    except:
        print("Error al grabar el archivo: ", nomArchGrabar)
def leer(nomArchLeer):
    """
    Funcionamiento: Carga la información del archivo
    """
    dicc={}
    try:
        f=open(nomArchLeer,"rb")
        dicc = pickle.load(f)
        f.close()
    except:
        FileNotFoundError
        grabarInicio("inventario",diccMenu)
    return dicc
