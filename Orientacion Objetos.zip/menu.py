#Elaborado por: Matías Cedeño León, Adrián Dittel Retana
#Fecha de Creación: 08/05/2019 8:00am
#Fecha de modificación: 09/05/2019 6:53pm
#Version: 3.7.2


#importación de librerías

from Libros import*
from funciones import*

def menu():
    """
    Funcionamiento: De manera repetitiva, muestra el menú al usuario. 
    Entradas: NA
    Salidas: Resultado según lo solicitado
    """
    biblioteca= leer("Biblioteca")
    while True:
        print("Menú Librería")
        print("1-Insertar libro")
        print("2-Modificar libro")
        print("3-Eliminar libro")
        print("4-Consultar libro")
        print("5-Terminar")
        opcion = int(input("Opción: "))
        if opcion == 1:
            agregarLibro(biblioteca,librito)
            print(biblioteca)
        elif opcion == 2:
            Isbn = input("Indique el ISBN a modificar: ").upper()
            modificarLibro(biblioteca,librito,Isbn)
        elif opcion == 3:
            eliminarLibro(biblioteca)
        elif opcion == 4:
            cond=int(input("Libro específica(1) o Todos los libros(2): "))
            if cond==1:
                Isbn = input("Indique el ISBN a mostrar: ").upper()
                mostrarLibros(biblioteca,Isbn)
            elif cond==2:
                mostrarTodosLibros(biblioteca)
            else:
                print("Indique un valor correcto (1-2)")
                cond=int(input("Libro específica(1) o Todos los libros(2): "))
        elif opcion == 5:
            grabar("Biblioteca",biblioteca)
            print ("Gracias por usar la biblioteca")
            break
#Programa Principal
menu()
