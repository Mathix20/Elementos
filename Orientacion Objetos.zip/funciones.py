#Elaborado por: Matías Cedeño León, Adrián Dittel Retana
#Fecha de Creación: 08/05/2019 8:00am
#Fecha de modificación: 09/05/2019 6:53pm
#Version: 3.7.2


from archivos import*
from Libros import*



biblioteca=[]
librito=Libro()
def agregarLibro(biblioteca,librito):
    """
    Entradas: Codigo,nombre,precio, ingredientes
    Funcionamiento: Crea los datos de la comida
    Salidas: Datos de la comida
    """
    Isbn = input("Indique el ISBN: ").upper()
    librito.SetIsbn(Isbn)
    nombre = input("Indique el nombre del libro: ").capitalize()
    librito.SetNombre(nombre)
    annopub= int(input("Indique el año de publicación: "))
    librito.SetAnnoPUB(annopub)
    biblioteca.append(librito)
    grabar("Biblioteca",biblioteca)
    return biblioteca
def modificarLibro(biblioteca,librito,Isbn):
    """
    Entradas: Codigo,nombre,precio, ingredientes
    Funcionamiento: Crea los datos de la comida
    Salidas: Datos de la comida
    """
    i=0
    while i<1:
        try:
            nombre = input("Indique el nombre del libro: ").capitalize()
            librito.SetNombre(nombre)
            annopub= int(input("Indique el año de publicación: "))
            librito.SetAnnoPUB(annopub)
            grabar("Biblioteca",biblioteca)
            i=10
        except:
            print("El ISBN no existe, digite un ISBN que exista")
            Isbn = input("Indique el ISBN: ").upper()
            librito.SetIsbn(Isbn)

def mostrarLibros(biblioteca,Isbn):
    i=0
    while i<len(biblioteca):
        try:
            if Isbn==biblioteca[i].GetIsbn():
                print("ISBN:"+str(biblioteca[i].GetIsbn()))
                print("Nombre:"+str(biblioteca[i].GetNombre()))
                print("Año de publicación:"+str(biblioteca[i].GetAnnoPUB()))
                print("-----------------------------------------------------")
                i+=1
        except:
            print("El ISBN no existe, digite un ISBN que exista")
            Isbn = input("Indique el ISBN: ").upper()
            i+1
def mostrarTodosLibros(biblioteca):
    i=0
    while i<len(biblioteca):
        try:
            print("ISBN:"+str(biblioteca[i].GetIsbn()))
            print("Nombre:"+str(biblioteca[i].GetNombre()))
            print("Año de publicación:"+str(biblioteca[i].GetAnnoPUB()))
            print("-----------------------------------------------------")
            i+=1
        except:
            if biblioteca == []:
                print("La biblioteca esta vacia")

def eliminarLibro(biblioteca):
    Isbn = input("Indique el ISBN: ").upper()
    i=0
    while i<len(biblioteca):
        if Isbn==biblioteca[i].GetIsbn():
            del(biblioteca[i])
            print("La informacion se ha eliminado correctamente")
            i+=1
        else:
            print("El ISBN indicado no existe")
            i+=10
