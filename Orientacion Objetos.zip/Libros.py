#Elaborado por: Matías Cedeño León, Adrián Dittel Retana
#Fecha de Creación: 08/05/2019 8:00am
#Fecha de modificación: 09/05/2019 6:53pm
#Version: 3.7.2


import pickle
from archivos import*


#El programa define la clase "Libro"
class Libro:
    """
    F:Método constructor = Crea la estructura de la clase Libro
    E:NA
    S:NA
    """
    def __init__(self):
        self.Isbn=""
        self.nombre=""
        self.annopub=0
    """
    F:Define el libro
    E:ISBN,nombre y año de publicación
    S:Asigna un nombre al atributo nombre del libro
    """    
    def SetIsbn(self,Isbn):
        self.Isbn=Isbn
    def GetIsbn(self):
        return self.Isbn
    def SetNombre(self,nombre):
        self.nombre=nombre
    def GetNombre(self):
        return self.nombre
    def SetAnnoPUB(self,annopub):
        self.annopub=annopub
    def GetAnnoPUB(self):
        return self.annopub
    def mostrarInfoLibro(self):
        return self.Isbn,self.nombre,self.annopub



    
    
    
